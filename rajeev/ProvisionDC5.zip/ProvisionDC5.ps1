Configuration MyWebServerCfg5 {
 
    Import-DscResource -ModuleName PsDesiredStateConfiguration
    Import-DscResource -ModuleName  xPSDesiredConfiguration 
   
node ("localhost") {
 
        # The first resource block ensures that the Web-Server (IIS) feature is enabled.
       # The second resource block ensures that the Web-Mgmt-Tools feature is enabled.
        
	WindowsFeature IIS-Tools {
            Ensure    = "Absent"
            Name      = "Web-Mgmt-Tools"
        }   
	WindowsFeature IIS {
            Ensure = "Absent"
            Name   = "Web-Server"
        }

    xRemoteFile ApachePackage {  
        Uri             = "https://de.apachehaus.com/downloads/httpd-2.4.38-o102q-x86-vc14.zip"
        DestinationPath = "c:\Users\babauser\httpd-2.4.38-o102q-x86-vc14.zip"
    }
 
 
    }
}
