Configuration MyWebServerCfg2 {
 
    Import-DscResource -ModuleName PsDesiredStateConfiguration
 
   node ("localhost") {
 
        # The first resource block ensures that the Web-Server (IIS) feature is enabled.
       # The second resource block ensures that the Web-Mgmt-Tools feature is enabled.
        
	WindowsFeature IIS-Tools {
            Ensure    = "Absent"
            Name      = "Web-Mgmt-Tools"
            DependsOn = "[WindowsFeature]IIS"
        }   
	WindowsFeature IIS {
            Ensure = "Absent"
            Name   = "Web-Server"
        }
 	    File ApacheDownload {
            Ensure = 'Present'
            SourcePath = 'https://de.apachehaus.com/downloads/httpd-2.4.38-o102q-x86-vc14.zip'
            DestinationPath = 'c:\Users\babauser'
        }
 
 
    }
}
